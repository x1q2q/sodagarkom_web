# SodagarKomputer WEB
Sistem Penjualan Komputer(e-commerce) menggunakan CI3 + TailwindCSS + AlpineJS
